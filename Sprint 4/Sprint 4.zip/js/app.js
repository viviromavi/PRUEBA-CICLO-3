document.querySelector("#basicToastBtn").onclick = function() {
    new bootstrap.Toast(document.querySelector('#basicToast')).show();
}